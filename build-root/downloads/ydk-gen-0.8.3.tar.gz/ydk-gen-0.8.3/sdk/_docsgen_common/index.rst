.. Yang Development Kit documentation master file, created by
   sphinx-quickstart on Fri Oct 30 15:19:51 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

YANG Development Kit (%s) Documentation
===========================================

Contents:
---------

.. toctree::
   :maxdepth: 2

   about_ydk.rst
   getting_started.rst
   developer_guide.rst
   api_guide.rst
