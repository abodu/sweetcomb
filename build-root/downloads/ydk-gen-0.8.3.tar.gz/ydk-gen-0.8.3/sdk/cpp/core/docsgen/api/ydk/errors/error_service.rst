YServiceError
================


.. cpp:class:: ydk::YServiceError : public YError

    Exception for service.

    .. cpp:function:: YServiceError(const std::string& msg)
