YModelError
==============


.. cpp:class:: ydk::YModelError : public YError

    This error is raised in case a model constraint is violated.

    .. cpp:function:: YModelError(const std::string& msg)
