YCoreError
=============


.. cpp:class:: ydk::path::YCoreError : public ydk::YError

    The subclasses give a specialized view of the error that has occurred.

    .. cpp:function:: YCoreError()

    .. cpp:function:: YCoreError(const std::string& msg)
