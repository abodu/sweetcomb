.. _ref-service:

Service
=======


.. toctree::
   :maxdepth: 2

   codec_service.rst
   crud_service.rst
   executor_service.rst
   netconf_service.rst
   validation_service.rst
   gnmi_service.rst
