YInvalidArgumentError
========================


.. cpp:class:: ydk::YInvalidArgumentError : public YError

    Use the msg for the error.

    .. cpp:function:: YInvalidArgumentError(const std::string& msg)
