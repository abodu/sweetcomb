Namespaces
==============

List of all namespaces with brief descriptions

   .. toctree::
    :maxdepth: 2

    nmsp_ydk.rst
