YClientError
===============

.. cpp:class:: ydk::YClientError : public YError

    .. cpp:function:: YClientError(const std::string& msg)
