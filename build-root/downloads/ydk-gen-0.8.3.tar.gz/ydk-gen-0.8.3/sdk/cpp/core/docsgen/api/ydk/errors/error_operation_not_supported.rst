YOperationNotSupportedError
==============================

Operation Not Supported Exception.


.. cpp:class:: ydk::YOperationNotSupportedError : public YError

    Thrown when an operation is not supported.

    .. cpp:function:: YOperationNotSupportedError(const std::string& msg)
