Errors Classes
==============


.. toctree::
   :maxdepth: 2

   error.rst
   error_client.rst
   error_service.rst
   error_illegal_state.rst
   error_invalid_argument.rst
   error_operation_not_supported.rst
   error_model.rst
