Before running tests do the following
 Prerequisites
 -------------
 1. confd is installed and confdrc is sourced

1. cd confd
2. make all
3. make start 

Now run make test in the cmake build directory

To stop confd do make stop

