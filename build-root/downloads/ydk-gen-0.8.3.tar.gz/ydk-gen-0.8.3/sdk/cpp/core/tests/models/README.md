The unit test run against netsim. The following models from this directory should be exported
to netsim
ietf-interfaces@2014-05-08.yang
main-aug1@2015-11-17.yang
main-aug2@2015-11-17.yang
main-aug3@2015-11-17.yang
main@2015-11-17.yang
openconfig-bgp-common-multiprotocol.yang
openconfig-bgp-common-structure.yang
openconfig-bgp-common.yang
openconfig-bgp-global.yang
openconfig-bgp-neighbor.yang
openconfig-bgp-peer-group.yang
openconfig-bgp-policy.yang
openconfig-bgp-types.yang
openconfig-bgp.yang
openconfig-extensions.yang
openconfig-interfaces.yang
openconfig-policy-types.yang
openconfig-routing-policy.yang
openconfig-types.yang
ydk@2016-02-26.yang
ydktest-filterread@2015-11-17.yang
ydktest-sanity-augm@2015-11-17.yang
ydktest-sanity-submodule@2016-04-25.yang
ydktest-sanity-types@2016-04-11.yang
ydktest-sanity@2015-11-17.yang
ydktest-types@2016-05-23.yang
