#YDK test bundle profiles

Contains profiles for bundles used in YDK tests.

