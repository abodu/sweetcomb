#YDK Release bundle profiles

Contains profiles for bundles used in YDK releases.

For example, the profiles `ietf_0_1_0.json`, `openconfig_0_1_0.json` and `cisco-ios-xr_0_1_0.json` were used to generate bundles released in [version 0.5.0](https://github.com/CiscoDevNet/ydk-gen/releases/tag/0.5.0).
